
 window.addEventListener("load", function() {

    function displayTime() {
      var currentTime = new Date();
      var hours = currentTime.getHours();
      var minutes = currentTime.getMinutes();
      var seconds = currentTime.getSeconds();
  
      
      var clockDiv = document.querySelector("#clock");

      setInterval(displayTime, 1000);
  
      // Then we set the text inside the clock div 
      // to the hours, minutes, and seconds of the current time

      if (seconds < 10) {
        // Add the "0" digit to the front
        // so 9 becomes "09"
        seconds = "0" + seconds;
    }

      clockDiv.innerHTML = hours + ":" + minutes + ":" + seconds;



    }
  
    // This runs the displayTime function the first time
    displayTime();
  
  });

  var countryname;

   let mainoperation = function()
   {

       countryname = document.querySelector("#inputid").value ; 

      let req = new XMLHttpRequest();

      const url = "https://corona.lmao.ninja/v2/countries/" + countryname ; 

      req.open('GET',url);

      req.onload = () =>
      {
         const data = JSON.parse(req.responseText);

         console.log(data);

         logic1(data);

      };

        req.send();

   };

   let logic1 = function (data)
   {

       const active1  = document.querySelector("#active");

        active.innerHTML = data.active;

       const cases1 = document.querySelector("#cases");

        cases1.innerHTML = data.cases;

        const critical1  = document.querySelector("#critical");

        critical1.innerHTML = data.critical;

        const death1  = document.querySelector("#death");

        death1.innerHTML = data.deaths;

        const recovered1  = document.querySelector("#recovered");

        recovered1.innerHTML = data.recovered;

        const tests1  = document.querySelector("#tests");

        tests1.innerHTML = data.tests;

        const head  = document.querySelector("#headid");

        head.innerHTML= "Covid Cases In " + " " + countryname;

        countryname = document.querySelector("#inputid").value = " ";
       
        
   }